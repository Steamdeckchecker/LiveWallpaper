// Canvas adapter for the animation engine by ryth9419-jpg.
// The GNOME/Cairo drawing backend is replaced with the browser's Canvas 2D API.
"use strict";

const GLib = {
    markup_escape_text(value) {
        return String(value).replace(/[&<>"']/g, character => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;"
        })[character]);
    }
};

class Ctx2D {
    constructor(canvas, scale = 1) {
        this.raw = canvas.getContext("2d");
        this.raw.scale(scale, scale);
    }
    set fillStyle(value) { this.raw.fillStyle = value; }
    get fillStyle() { return this.raw.fillStyle; }
    set strokeStyle(value) { this.raw.strokeStyle = value; }
    get strokeStyle() { return this.raw.strokeStyle; }
    set lineWidth(value) { this.raw.lineWidth = value; }
    get lineWidth() { return this.raw.lineWidth; }
    set lineCap(value) { this.raw.lineCap = value; }
    set lineJoin(value) { this.raw.lineJoin = value; }
    set globalAlpha(value) { this.raw.globalAlpha = value; }
    get globalAlpha() { return this.raw.globalAlpha; }
    set globalCompositeOperation(value) { this.raw.globalCompositeOperation = value; }
    get globalCompositeOperation() { return this.raw.globalCompositeOperation; }
    // The original Cairo adapter also ignores blur, keeping the same workload.
    set shadowBlur(value) {}
    set shadowColor(value) {}
    fillRect(...values) { this.raw.fillRect(...values); }
    beginPath() { this.raw.beginPath(); }
    closePath() { this.raw.closePath(); }
    moveTo(...values) { this.raw.moveTo(...values); }
    lineTo(...values) { this.raw.lineTo(...values); }
    bezierCurveTo(...values) { this.raw.bezierCurveTo(...values); }
    rect(...values) { this.raw.rect(...values); }
    arc(...values) { this.raw.arc(...values); }
    ellipse(...values) { this.raw.ellipse(...values); }
    fill() { this.raw.fill(); }
    stroke() { this.raw.stroke(); }
    clip() { this.raw.clip(); }
    save() { this.raw.save(); }
    restore() { this.raw.restore(); }
    translate(...values) { this.raw.translate(...values); }
    rotate(...values) { this.raw.rotate(...values); }
    scale(...values) { this.raw.scale(...values); }
    createRadialGradient(...values) { return this.raw.createRadialGradient(...values); }
    createLinearGradient(...values) { return this.raw.createLinearGradient(...values); }
    drawImage(image, x, y, width, height) {
        const source = image.canvas || image.image;
        if (!source) return;
        this.raw.drawImage(source, x, y, width === undefined ? image.w : width,
                          height === undefined ? image.h : height);
    }
    layout(text, size, markup = false) {
        const runs = [];
        if (markup) {
            const parsed = new DOMParser().parseFromString("<root>" + text + "</root>", "application/xml");
            function walk(node, color, alpha) {
                if (node.nodeType === Node.TEXT_NODE) {
                    runs.push({text: node.nodeValue, color, alpha});
                    return;
                }
                if (node.nodeType !== Node.ELEMENT_NODE) return;
                const nextColor = node.getAttribute("foreground") || color;
                const opacity = node.getAttribute("fgalpha");
                const nextAlpha = opacity ? alpha * parseFloat(opacity) / 100 : alpha;
                for (const child of node.childNodes) walk(child, nextColor, nextAlpha);
            }
            walk(parsed.documentElement, null, 1);
        } else {
            runs.push({text: String(text), color: null, alpha: 1});
        }
        this.raw.save();
        this.raw.font = size + "px monospace";
        let width = 0;
        for (const run of runs) {
            run.width = this.raw.measureText(run.text).width;
            width += run.width;
        }
        this.raw.restore();
        return {runs, size, get_pixel_size: () => [width, Math.ceil(size * 1.4)]};
    }
    drawLayout(layout, x, y) {
        this.raw.save();
        this.raw.font = layout.size + "px monospace";
        this.raw.textBaseline = "top";
        const alpha = this.raw.globalAlpha;
        for (const run of layout.runs) {
            if (run.color) this.raw.fillStyle = run.color;
            this.raw.globalAlpha = alpha * run.alpha;
            this.raw.fillText(run.text, x, y);
            x += run.width;
        }
        this.raw.restore();
    }
}

const scaledSize = (size, scale) => Math.max(1, Math.ceil(size * scale));
function makeLayer(width, height, scale = 1) {
    const canvas = document.createElement("canvas");
    canvas.width = scaledSize(width, scale);
    canvas.height = scaledSize(height, scale);
    return {canvas, w: width, h: height, rs: scale, ctx: new Ctx2D(canvas, scale)};
}
