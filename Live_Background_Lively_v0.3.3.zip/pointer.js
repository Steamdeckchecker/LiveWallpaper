"use strict";

// Keep short taps until a rendered frame has seen the press. A quick release
// must not erase the press while the Qt/WebEngine bridge is between frames.
class PointerState {
    constructor() { this.clear(); }
    clear() {
        this.current = null;
        this.presses = [];
        this.last = null;
        this.deliveredDown = false;
    }
    update(value) {
        if (value === null) {
            this.current = null;
            return;
        }
        if (!value || !Number.isFinite(value.x) || !Number.isFinite(value.y)) {
            this.clear();
            return;
        }
        const next = {x: value.x, y: value.y, down: Boolean(value.down), free: value.free !== false};
        if (next.down && !this.current?.down) {
            if (this.presses.length < 8) this.presses.push({...next});
        }
        this.current = next;
    }
    frame() {
        if (this.presses.length) {
            if (this.deliveredDown) {
                this.deliveredDown = false;
                return {...this.last, down: false};
            }
            this.last = this.presses.shift();
            this.deliveredDown = true;
            return {...this.last};
        }
        this.deliveredDown = Boolean(this.current?.down);
        if (this.current) this.last = this.current;
        return this.current ? {...this.current} : null;
    }
}
